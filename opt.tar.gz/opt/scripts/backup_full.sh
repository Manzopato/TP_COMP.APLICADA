#!/bin/bash

# Script de backup simple: backup_full.sh

# Si pide ayuda
if [[ "$1" == "-help" ]]; then
    echo "Uso: $0 origen destino"
    echo "Ejemplo: $0 /var/log /backup_dir"
    exit 0
fi

# Validar que me pasaron 2 argumentos
if [[ $# -ne 2 ]]; then
    echo "Error: se necesitan 2 argumentos: origen y destino."
    exit 1
fi

ORIGEN=$1
DESTINO=$2

# Validar que el origen existe
if [[ ! -d "$ORIGEN" ]]; then
    echo "Error: el directorio de origen $ORIGEN no existe."
    exit 2
fi

# Validar que el destino existe
if [[ ! -d "$DESTINO" ]]; then
    echo "Error: el directorio de destino $DESTINO no existe."
    exit 3
fi

# Armar el nombre del archivo de backup
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")_bkp_${FECHA}.tar.gz

# Hacer el backup
tar -czf "$DESTINO/$NOMBRE" "$ORIGEN"

echo "Backup terminado: $DESTINO/$NOMBRE"

